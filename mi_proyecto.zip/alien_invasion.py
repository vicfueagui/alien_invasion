# alien_invasion.py

import pygame
from pygame.sprite import Group

from configuraciones import Configuraciones
from nube import Nube
import funciones_juego as fg


def ejecutar_juego():
    # Inicializa pygame, configuración y objeto de pantalla
    pygame.init()
    ai_configuraciones = Configuraciones()
    pantalla = pygame.display.set_mode((ai_configuraciones.ancho_pantalla, ai_configuraciones.altura_pantalla))
    pygame.display.set_caption("Alien Invasion")

    # Crea tu nube.
    nube = Nube(ai_configuraciones, pantalla)
    # Crea un grupo para almacenar balas
    balas = Group()

    # Inicia el bucle principal del juego
    while True:
        # Este atento a los eventos del teclado y mouse.
        fg.verificar_eventos(ai_configuraciones, pantalla, nube, balas)
        # Actualiza la posición de la nube
        nube.actualizacion()
        # Actualiza la posición de las balas
        balas.update(balas)
        # Redibuja la pantalla y los elementos en ella.
        fg.actualizar_pantalla(ai_configuraciones, pantalla, nube, balas)


ejecutar_juego()